// PizzaHut.java

public class PizzaHut {
    // Fields representing PizzaHut
    private int pizzaCount; // pizzas sold
    private String specialPizza; //the special pizza of the month
    private double deliveryCharge; // charge for orders that were delivered

    // Constructor that accepts all fields
    public PizzaHut(int pizzaCount, String specialPizza, double deliveryCharge) {
        this.pizzaCount = pizzaCount;
        this.specialPizza = specialPizza;
        this.deliveryCharge = deliveryCharge;
    }

    public PizzaHut() {
        this.pizzaCount = 0; // Default to 0 pizzas that were sold
        this.specialPizza = null; // Default to no special pizza
        this.deliveryCharge = 0.0; // Default to no delivery charge
    }

    // pizzaCount
    public int getPizzaCount() {
        return pizzaCount;
    }

    public void setPizzaCount(int pizzaCount) {
        this.pizzaCount = pizzaCount;
    }

    // specialPizza
    public String getSpecialPizza() {
        return specialPizza;
    }

    public void setSpecialPizza(String specialPizza) {
        this.specialPizza = specialPizza;
    }

    // deliveryCharge
    public double getDeliveryCharge() {
        return deliveryCharge;
    }

    public void setDeliveryCharge(double deliveryCharge) {
        this.deliveryCharge = deliveryCharge;
    }

    // discounts for pizzahut
    public void offerSpecialDeal() {
        System.out.println("Special Deal! Get 20% off on " + specialPizza + " this month!");
    }

    //display all the attributes of PizzaHut
    public void printDetails() {
        System.out.println("Pizza Count: " + pizzaCount);
        System.out.println("Special Pizza: " + specialPizza);
        System.out.println("Delivery Charge: $" + deliveryCharge);
    }
}
