// McDonalds.java

public class McDonalds {
    // Fields representing McDonalds
    private int customerCount; // Number of customers served
    private String burgerOfTheDay; // Name of the burger of the day
    private double friesPrice; // Price of fries

    // accepts all fields
    public McDonalds(int customerCount, String burgerOfTheDay, double friesPrice) {
        this.customerCount = customerCount;
        this.burgerOfTheDay = burgerOfTheDay;
        this.friesPrice = friesPrice;
    }

    // sets all fields to default values
    public McDonalds() {
        this.customerCount = 0; // Default to 0 customers served
        this.burgerOfTheDay = null; // Default to no burger of the day
        this.friesPrice = 0.0; // Default to 0 fries price
    }

    // customerCount
    public int getCustomerCount() {
        return customerCount;
    }

    public void setCustomerCount(int customerCount) {
        this.customerCount = customerCount;
    }

    // burgerOfTheDay
    public String getBurgerOfTheDay() {
        return burgerOfTheDay;
    }

    public void setBurgerOfTheDay(String burgerOfTheDay) {
        this.burgerOfTheDay = burgerOfTheDay;
    }

    // friesPrice
    public double getFriesPrice() {
        return friesPrice;
    }

    public void setFriesPrice(double friesPrice) {
        this.friesPrice = friesPrice;
    }

    // mcdonalds promote burger
    public void greetCustomer() {
        System.out.println("Welcome to McDonald's! Enjoy our " + burgerOfTheDay + " today!");
    }

    // display all the attributes of McDonalds
    public void printDetails() {
        System.out.println("Customer Count: " + customerCount);
        System.out.println("Burger of the Day: " + burgerOfTheDay);
        System.out.println("Fries Price: $" + friesPrice);
    }
}