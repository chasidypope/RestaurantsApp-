// RestaurantApp.java
/*
name: Chasidy Pope
course: 14349
date: 8/31/2024
program objective: This application creates objects for two favorite restaurants and it
displays their attributes, modifies one attribute for each, and then displays the updated information.
input: None
output: Attributes of each restaurant before and after
 */

public class RestaurantApp {
    public static void main(String[] args) {
        // objects for each restaurant
        PizzaHut pizzaHut = new PizzaHut(100, "Pepperoni Supreme", 3.99);
        McDonalds mcDonalds = new McDonalds(200, "Big Mac", 2.49);

        // attributes for both restaurants
        System.out.println("Initial PizzaHut Details:");
        pizzaHut.printDetails(); // details of PizzaHut
        pizzaHut.offerSpecialDeal(); //  special deal for PizzaHut
        System.out.println();

        System.out.println("Initial McDonalds Details:");
        mcDonalds.printDetails(); // details of McDonalds
        mcDonalds.greetCustomer(); // greeting for McDonalds
        System.out.println();

        // modified one of the attributes for each restaurant
        pizzaHut.setPizzaCount(150); // Changing pizza count for PizzaHut
        mcDonalds.setFriesPrice(2.99); // Changing fries price for McDonalds

        // updated attributes for both restaurants
        System.out.println("Updated PizzaHut Details:");
        pizzaHut.printDetails(); //  updated details of PizzaHut
        System.out.println();

        System.out.println("Updated McDonalds Details:");
        mcDonalds.printDetails(); //  updated details of McDonalds
    }
}